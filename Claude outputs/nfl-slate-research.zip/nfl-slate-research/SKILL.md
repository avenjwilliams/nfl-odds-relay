---
name: nfl-slate-research
description: Research every NFL game on a given day and produce a shareable doc with per-game findings and recommended FanDuel player props and game-line bets. Use when the user asks for NFL betting research, picks, props, best bets, or a slate breakdown for a date or week.
---

# NFL slate research → FanDuel picks doc

Produces one Claude Doc per slate: a slate summary, a section per game (lines, weather, injuries,
matchup findings, projected script, recommended bets), and a bet log. Recommendations come from
explicit projections priced against FanDuel lines, never from narrative alone. "No bet" is a valid
and common result for a game.

## 0. Settle the slate

- Get the current date/time with the time tool. Slate date = the date the user names, else the next
  date with NFL games (Thursday, Sunday, or Monday). Sunday runs cover every Sunday game, including
  international early kickoffs.
- If kickoff for a game has already passed, skip it and say so.

## 1. Pull the free data (≈1 minute)

```bash
pip install nflreadpy pandas pyarrow scipy --break-system-packages -q
python3 <skill_dir>/scripts/pull_slate.py --date YYYY-MM-DD --out <scratchpad>/slate_YYYY-MM-DD
```

This writes `slate.json` plus one `<game_id>.md` packet per game with: venue/roof/surface/rest,
consensus spread and total with implied team totals, team pace, neutral pass rate, PROE,
EPA/success season vs. last 4 weeks, offense-vs-defense EPA/success by play type (play action,
motion, screens, RPO, vs. blitz, box count, deep, red zone), defensive blitz and box rates,
what each defense allows to receivers and runners, player usage (snap %, target share,
air-yards share, aDOT, rush share, inside-10 carries, QB volume) with game logs, and the
official practice/injury report. Read every packet before researching.

Data caveats to carry into the doc: nflverse updates overnight, so the latest week can lag;
FTN charting splits can be missing for the most recent games; man/zone coverage and two-high
shell rates are not in the free 2026 data and must come from web research.

## 2. Open the doc first

Load the `docs` skill, then create the doc skeleton before researching:
title `NFL Slate — <Day, Mon D YYYY>`, byline, and a pending block for
"Slate summary", one per game in kickoff order, "Bet log", and "Method & sources".
Fill sections as each game is finished so the user can watch it build. Layout is in
`references/doc-template.md`.

## 3. Research each game

Work game by game through `references/research-checklist.md` (injuries & practice trends,
coverage tendencies, weather, coaching/situational notes, beat-writer usage news). Search each
team separately rather than combining queries. Write down only findings that change a projection
or a bet; skip trivia.

## 4. Get FanDuel lines

Start with the GitHub relay (`scripts/load_lines.py`), which loads every US book,
then follow the rest of `references/fanduel-lines.md` for any gaps. Build candidates from
`candidates_template.csv`: project every prop listed for players with meaningful usage, not just
the obvious ones. FanDuel is the quoted price; the consensus across books is the market
probability. Every line in the doc carries its source and the time it was seen. Never invent or "estimate" a FanDuel number. If a prop line can't be found, publish the
projection with a playable threshold instead (e.g., "Higher is playable at 64.5 or lower").

## 5. Project and price

Follow `references/projection-method.md` to build projections, write them to a
`candidates.csv`, and run:

```bash
python3 <skill_dir>/scripts/price.py --csv candidates.csv --out priced.csv
```

`price.py` uses the consensus no-vig probability when the row has one (otherwise removes the
single book's vig), converts the projection to a probability (gamma for yardage,
Poisson for counts/TDs, normal for spreads and totals), and assigns a tier:
**A** and **B** are recommendations, **lean** is listed but not recommended, **pass** is dropped.
Game lines need about twice the edge of props before they reach a tier.

## 6. Choose the bets

- Recommend A and B tiers only; at most 3 per game and about 12 per slate. Rank by EV.
- **Always show the best available.** If fewer than 3 bets on the slate (or none in a game)
  reach A/B, still list the top 3 candidates by EV under "Best available (below threshold)",
  each with its tier (lean or pass), EV, and what line or news would push it into a
  recommendation. A game section never ends with nothing but "No bet".
- **Stale lines:** if a line was posted before major news (QB change, star ruled out, big
  weather shift), still price it, flag it ⚠ "pre-news line", and say which way the market has
  likely moved (cite other books' current numbers if found). A flagged bet can be listed but
  can't be tier A.
- Check correlation: don't recommend both a QB yardage Over and his top WR Under, or several
  bets that all need the same game script, without saying they are correlated.
- Each recommendation states: the bet and FanDuel price, projection vs. line, model vs. market
  probability, tier, a 1–2 sentence reason grounded in the findings, and what news would kill it
  (e.g., "pass if X is ruled out").
- Note when inactives (90 minutes before kickoff) could change a pick.

## 7. Finish the doc

Write the slate summary last: top plays ranked, games with no bet, key injury watch-list, and
the timestamp the lines were captured. Add every recommended bet to the bet log table with an
empty Result column. End the doc with method notes and sources. In chat, give a one-line
wrap-up and the doc link; don't repeat the doc.

## Grading a previous slate

If the user links a previous slate doc and asks how it did, read its bet log, pull final stats
with nflreadpy (`load_player_stats` / `load_schedules`), fill the Result and closing-line columns,
and summarize hit rate, units, and whether bets beat the closing line.

## Timing guidance to share when relevant

Practice reports finalize Friday; Sunday's best run is Saturday with a refresh Sunday morning;
Thursday and Monday games get their own runs. Props move most on injury news, so stale lines
are the main risk.
