# Doc layout

Title: `NFL Slate — <Day, Mon D YYYY>`. Under the title: date, byline, and a one-line note of when
lines were captured and from where.

## Slate summary
- **Top plays** table, ranked by EV: Game · Bet (e.g., "Amon-Ra St. Brown Over 6.5 receptions")
  · FanDuel price · Projection vs. line · Model % vs. market % · Tier.
- **Best available** when fewer than 3 bets clear the bar: the top candidates by EV across the
  slate, clearly labeled as below threshold.
- **No-bet games**, one line each with the reason.
- **Injury watch-list:** questionable players whose status changes a recommended bet, with what to
  do if they sit.
- **Data notes:** latest week of data, any missing charting, line sources.

## <Away> @ <Home> — <kickoff local time> (one section per game, kickoff order)
**Lines:** spread, total, and moneyline with FanDuel prices (source, time) · implied team totals ·
weather or roof · rest.

**Key injuries:** who is out or questionable and who absorbs the volume.

**Matchup findings:** 3–5 bullets, each one sentence tying a number from the packet or research
to a direction (shape: "<defense> allows <X> EPA/play on play action vs. <Y> without it, and
<offense> uses play action on <Z>% of dropbacks: helps <QB> and <deep WR>").

**Projected script:** one or two sentences: pace, pass/run lean, expected game flow.

**Recommended bets:** one entry per bet:
- **Bet @ price (tier)**: projection vs. line; model vs. market probability.
- Why, in 1–2 sentences.
- Kill switch: the news that voids it.

If nothing clears the bar, say so in one sentence, then always add **Best available (below
threshold)**: the top 1–3 candidates in the game by EV, each with tier, EV, and what would make it
a bet (a better line, an injury resolving). Props without a line show their playable threshold.

Lines posted before major news carry a ⚠ pre-news flag with the likely direction of the move.

## Bet log
Table: Date · Game · Bet · Price · Line at bet · Projection · Tier · Closing line · Result · Units.
Closing line and Result stay blank until graded.

## Method & sources
Short paragraph on the model (volume × share × efficiency, priced with no-vig market
probabilities) and its limits, then a list of the sources used with links.
