# Getting lines

FanDuel is the quoted book: when FanDuel has a line, recommend at FanDuel's number and price.
Other books and Kalshi supply the market probability, the best available price, and lines
FanDuel hasn't posted. Every line written to the doc includes its source ("FanDuel (relay)",
"DraftKings (relay)", "Kalshi", "FanDuel per <site>", "user-provided", or "consensus — not
FanDuel") and the local time it was seen. Never invent a number. If sources disagree, use the
most recent and say so.

## Tier 0 — GitHub odds relay (preferred; works in cloud runs)
A GitHub Action in `avenjwilliams/nfl-odds-relay` pulls game lines and props from every US book on
The Odds API, plus Kalshi NFL markets, at 6:45 AM Central on Sun/Mon/Thu and commits them as JSON.
```bash
python3 <skill_dir>/scripts/load_lines.py --date YYYY-MM-DD --out <slate_dir>
```
Outputs:
- `game_board.csv` and `props_board.csv`: per line, FanDuel's price (`fd_*`), the best price and
  its book, `consensus_*_prob` (median no-vig probability across books at the same line),
  `n_books`, and `alt_lines` (books hanging a different number; useful line shopping). The
  reference line is FanDuel's when it has one, else the most common line.
- `candidates_template.csv`: every board line in `price.py` format with `market_prob_over` set to
  the consensus. Fill `proj` (and `log`) for lines worth projecting; rows left blank are skipped.
  For lines without a FanDuel price the template uses the best book's price and names the book.
- `kalshi.csv`: Kalshi markets for the date with `mid_prob` (midpoint of yes bid/ask). Read titles
  to match them to games and props. Use a Kalshi mid only when `spread_cents` ≤ 6 and there's
  real volume. It's a cross-check on the consensus, or the market probability for a prop no book
  offers. Kalshi prices are probabilities, not American odds.

Rules:
- Exit code 2 means no file for that date (relay didn't run, or the slate is a different day).
  Continue to Tier 1.
- If the file is more than ~12 hours old, or news broke after `fetched_at` (check injury and QB
  news timestamps), treat affected lines as ⚠ pre-news.
- Relay notes about skipped props, FanDuel props not posted yet, or low credits go in the doc's
  data notes.
- When a recommended bet has no FanDuel line, say so plainly: "Not on FanDuel yet; DraftKings
  Over 54.5 -105". When FanDuel's price is worse than the best price by 10+ cents, mention the
  better book.
- Player names follow each book's spelling; match to the packet by last name and team.

## Tier 1 — FanDuel Sportsbook in the user's Chrome
Use Claude in Chrome (load the `chrome-browser` skill first). This only reads public pages; never
sign in, place bets, or click anything that would.
1. Open `sportsbook.fanduel.com/navigation/nfl` in a new tab and read the page text for each
   game's spread, total, and moneyline with prices.
2. Open each game's page and read the player-prop tabs (passing, rushing, receiving, TD scorer).
   Capture Over/Under lines and both prices.
3. FanDuel geo-restricts some states. If the page shows a location block, an empty board, or a
   sign-in wall, stop using Tier 1 for this run and say so in the doc's method notes.
4. Close the tabs you opened.
If Chrome isn't reachable, mention it in one line and move to Tier 2.

## Tier 2 — Web sources that quote FanDuel prices
- WebSearch queries such as "<away> vs <home> odds FanDuel <date>" and
  "<player> props FanDuel <date>"; FanDuel Research previews, odds roundups, and prop articles
  often list FanDuel's number. Fetch the page and confirm the article date matches this slate;
  discard anything older than about 48 hours for props and 72 hours for game lines.
- Search results mix seasons; check the year and week every time.
- Label these lines "FanDuel per <source>, <date>" and note they may have moved.

## Tier 3 — Ask the user
If a high-value candidate has no FanDuel line after Tiers 1–2, list those players and markets in
one message and ask the user to paste the lines or a screenshot. When the user isn't around
(scheduled run), skip this and use thresholds.

## Fallbacks
- Game lines: the packet's nflverse consensus spread and total may be used for projections
  and implied team totals, labeled "consensus — not FanDuel". Don't recommend a game-line bet
  priced only from consensus.
- Props with no line: show the projection and a playable threshold from `price.py` instead of a
  recommendation. Find the line at which EV turns positive at -110 by pricing a few candidate lines
  (e.g., "Higher playable at ≤ 64.5, Lower at ≥ 78.5").
