# Projection method

Projections are means for the full game. Keep the arithmetic in a short Python cell so the numbers
are reproducible, and write each candidate to `candidates.csv` for `price.py` (column spec is in
the script's docstring). Include the player's recent game log for that stat in the `log` column.

## Team volume
1. **Plays:** average of the team's plays per game (recent 4 weeks weighted 60%, season 40%) and
   the opponent's plays allowed per game. Adjust ±2 plays for pace notes, weather, or clock-heavy
   game plans.
2. **Pass rate:** start from the team's neutral pass rate, then shift for script. Roughly −2 points
   of pass rate per point of favoritism beyond 3, and +2 per point of underdog status beyond
   3, capped at ±8. Add PROE context: a team with strongly negative PROE stays run-leaning even
   when trailing.
3. **Dropbacks** = plays × pass rate; **pass attempts** ≈ dropbacks × (1 − sack rate − scramble
   rate ~3%). **Rush attempts** = plays − dropbacks (minus kneels).
4. Sanity check: projected team points should land within about 3 of the implied team total.
   If not, revisit the efficiency inputs before going further.

## Efficiency
- Blend the offense's rate with what the defense allows, 55% offense / 45% defense:
  yards per pass attempt, yards per target, yards per carry, completion rate.
- Apply research adjustments explicitly and modestly (most ±3–10%): coverage matchup, missing
  corners or linemen, blitz vulnerability, weather (15+ mph wind: −8–12% to passing yards).
  Every adjustment must name the finding that justifies it.

## Players
- **Targets** = team pass attempts × target share (recent 4 weeks 60%, season 40%), then
  reallocate vacated targets from absent players by role (WR to WR, slot to slot/TE), not
  evenly.
- **Receptions** = targets × catch rate (player's season rate, shrunk 30% toward the position
  norm: WR ~64%, TE ~72%, RB ~78%).
- **Receiving yards** = targets × yards per target (player's rate blended with the defense's
  allowed yards per target).
- **Carries** = team rush attempts × rush share; **rushing yards** = carries × blended yards per
  carry. Add QB scrambles for mobile QBs.
- **Passing yards** = pass attempts × blended yards per attempt.
- **Anytime TD** expected TDs ≈ team projected TDs (implied total ÷ 7, minus ~0.4 for field goals)
  × the player's share of red-zone targets plus inside-10 carries (shrink toward role averages).
- **Snap caps:** cut a player's share when the reporting suggests a limited role or a return from
  injury.

## Game lines
Start from the FanDuel line, not from scratch. The market is sharp, so a game-line projection
= market margin or total + explicit adjustments for things the market may be slow on (late
injuries, wind forecast changes, QB changes). Cap total adjustments at 3 points and justify each
one. If no adjustment applies, there is no game-line bet.

## What the pricing does with it
- Yardage stats are skewed: the median falls below the mean, so a projection a few yards above a
  line can still price as a coin flip. That's intended.
- Ties of the probability with the no-vig market mean no edge. The tier rules in `price.py`
  decide recommendations; don't override a "pass" because the story is good.
