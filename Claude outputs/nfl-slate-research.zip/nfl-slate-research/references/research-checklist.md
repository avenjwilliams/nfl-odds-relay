# Per-game research checklist

Work through these for every game after reading its data packet. Record only findings that move a
projection, a line, or a bet; each finding should say which way it pushes and roughly how much.

## 1. Injuries (highest priority)
- Official designations (Out / Doubtful / Questionable) and the practice trend across the week
  (DNP → Limited → Full is good news; Full → Limited late in the week is bad news). The packet has
  nflverse's report; confirm with a web search for "<team> injury report" from the last 24 hours.
- Look beyond stars: offensive line starters (pressure, run game), cornerbacks and safeties
  (opposing WR/TE props), and pass rushers.
- For every likely absence, name who absorbs the snaps, targets, or carries, using the packet's
  usage table and beat-writer reports. Vacated volume is often the best prop edge on the slate.
- Players returning from injury: expect a snap cap in the first game back unless reporting says
  otherwise.

## 2. Defensive scheme (fills the gap in free data)
- Search for each defense's man vs. zone rate and single-high vs. two-high shell rate this season
  (articles from PFF, FTN, Fantasy Points, The Athletic, and fantasy sites often cite them).
  Record the number, the source, and its date.
- Map it to the opponent: which receivers beat man (separation, contested catches) vs. zone
  (slot, underneath). Two-high shells suppress deep targets and push volume to RBs, TEs, and
  slot receivers; single-high plus man invites deep shots.
- Use the packet's blitz rate and "dropbacks vs blitz" splits: an offense that struggles vs. the
  blitz facing a high-blitz defense hurts QB yardage and helps sacks and interceptions.
- Shadow cornerbacks: check whether a CB follows the opponent's WR1.

## 3. Offensive success by play type (from the packet)
- Compare offense split vs. the defense's allowed split for the same play type. Flag mismatches
  of roughly 0.15+ EPA/play or 8+ success-rate points on samples of 30+ plays.
- Play action rate × defensive play-action vulnerability; motion; screens; RPO; run game vs.
  light boxes.
- Red-zone efficiency for both sides (TD props).

## 4. Pace, volume, and script
- Plays per game, neutral pass rate, and PROE for both teams, recent vs. season.
- Projected script from the spread: big favorites run more in the second half; big underdogs
  throw more. Note when a team's tendencies contradict that (e.g., a pass-heavy favorite).

## 5. Weather and venue
- Domes and closed roofs: skip weather. Retractable roofs: search for the expected roof status.
- Outdoors: get the forecast for the stadium city at kickoff with the weather tool if available,
  else a web search for the hourly forecast. Sustained wind of 15+ mph meaningfully hurts passing
  and kicking (lean passing Unders and game Unders); heavy rain or snow trims passing slightly
  and raises fumbles. Cold alone matters little.
- International games and long travel; short rest; altitude in Denver.

## 6. Situational and coaching
- Rest differential (packet), short weeks, bye-week returns.
- Coordinator or play-caller changes and QB changes since the season-long data was built;
  weight recent weeks more after one.
- Beat-writer notes on role changes (new starter, committee backfield, snap-count plans).
- Divisional familiarity and rematch notes only when there is a concrete tactical reason.

## 7. Market context
- FanDuel opening vs. current spread and total if findable; note big moves and whether they
  line up with injury news.
- Implied team totals (from the packet or the FanDuel line) anchor every player projection.

## Output per game (feeds the doc)
- 3–5 key findings, each one sentence, each tied to a direction (helps/hurts whom).
- A projected script in one sentence.
- Candidate bets for pricing (more candidates than recommendations; pricing filters them).
