#!/usr/bin/env python3
"""Read the odds relay file (all US books) and build line boards for pricing.

Usage:
    python3 load_lines.py --date 2026-11-08 --out <slate_dir> [--repo avenjwilliams/nfl-odds-relay]
    python3 load_lines.py --file odds.json --out <slate_dir>          # local file (testing)

Writes to <out>:
    game_board.csv    spreads / totals / moneylines: FanDuel price, best price + book,
                      consensus no-vig probability across books at the same line
    props_board.csv   player props: same columns, plus lines other books hang at other numbers
    candidates_template.csv   every board line pre-filled in price.py's format; fill in `proj`
                              (and `log`) and delete rows you won't project
Exit code 2 = no relay file for that date (fall back to web sources).
"""
import argparse
import csv
import json
import os
import statistics
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone

TEAMS = {
    "Arizona Cardinals": "ARI", "Atlanta Falcons": "ATL", "Baltimore Ravens": "BAL", "Buffalo Bills": "BUF",
    "Carolina Panthers": "CAR", "Chicago Bears": "CHI", "Cincinnati Bengals": "CIN", "Cleveland Browns": "CLE",
    "Dallas Cowboys": "DAL", "Denver Broncos": "DEN", "Detroit Lions": "DET", "Green Bay Packers": "GB",
    "Houston Texans": "HOU", "Indianapolis Colts": "IND", "Jacksonville Jaguars": "JAX", "Kansas City Chiefs": "KC",
    "Las Vegas Raiders": "LV", "Los Angeles Chargers": "LAC", "Los Angeles Rams": "LA", "Miami Dolphins": "MIA",
    "Minnesota Vikings": "MIN", "New England Patriots": "NE", "New Orleans Saints": "NO", "New York Giants": "NYG",
    "New York Jets": "NYJ", "Philadelphia Eagles": "PHI", "Pittsburgh Steelers": "PIT", "San Francisco 49ers": "SF",
    "Seattle Seahawks": "SEA", "Tampa Bay Buccaneers": "TB", "Tennessee Titans": "TEN", "Washington Commanders": "WAS",
}
STAT = {"player_pass_yds": "pass_yds", "player_pass_tds": "pass_td", "player_rush_yds": "rush_yds",
        "player_reception_yds": "rec_yds", "player_receptions": "receptions", "player_anytime_td": "anytime_td"}
GAME_MKT = {"h2h": "moneyline", "spreads": "spread", "totals": "total"}
FD = "fanduel"
TD_HOLD = 1.06  # rough hold on one-sided TD scorer markets


def implied(a):
    a = float(a)
    return 100 / (a + 100) if a > 0 else -a / (-a + 100)


def better(a, b):
    """True if American price a pays more than b."""
    return b is None or implied(a) < implied(b)


def fetch(repo, date):
    url = f"https://raw.githubusercontent.com/{repo}/main/odds/{date}.json"
    r = subprocess.run(["curl", "-sS", "-f", "-m", "20", url], capture_output=True, text=True)
    return (json.loads(r.stdout), url) if r.returncode == 0 and r.stdout.strip() else (None, None)


def ref_line(lines_by_book):
    """FanDuel's line if it has one, else the most common line."""
    if FD in lines_by_book:
        return lines_by_book[FD], "FanDuel"
    c = Counter(lines_by_book.values()).most_common(1)
    return (c[0][0], "consensus") if c else (None, None)


def game_board(g):
    away, home = TEAMS.get(g["away_team"], g["away_team"]), TEAMS.get(g["home_team"], g["home_team"])
    game = f"{away}@{home}"
    # quotes[(market, selection)][book] = (point, price, other_side_price)
    quotes = defaultdict(dict)
    for b in g.get("game_books", []):
        for m in b.get("markets", []):
            outs = m.get("outcomes", [])
            if len(outs) != 2:
                continue
            for i, o in enumerate(outs):
                other = outs[1 - i]
                sel = TEAMS.get(o["name"], o["name"])
                quotes[(GAME_MKT.get(m["key"], m["key"]), sel)][b["key"]] = (o.get("point"), o["price"], other["price"])
    rows = []
    for (mkt, sel), books in quotes.items():
        line, src = ref_line({k: v[0] for k, v in books.items()})
        at = {k: v for k, v in books.items() if v[0] == line}
        probs = [implied(p) / (implied(p) + implied(q)) for _, p, q in at.values()]
        best, best_book = None, ""
        for k, (_, p, _) in at.items():
            if better(p, best):
                best, best_book = p, k
        alt = sorted({f"{k} {v[0]}" for k, v in books.items() if v[0] != line})
        fd = books.get(FD)
        rows.append({"game": game, "market": mkt, "selection": sel, "line": "" if line is None else line,
                     "line_source": src, "fd_odds": fd[1] if fd and fd[0] == line else "",
                     "best_odds": best, "best_book": best_book,
                     "consensus_prob": round(statistics.median(probs), 4) if probs else "",
                     "n_books": len(at), "alt_lines": "; ".join(alt)})
    return rows


def props_board(g):
    away, home = TEAMS.get(g["away_team"], g["away_team"]), TEAMS.get(g["home_team"], g["home_team"])
    game = f"{away}@{home}"
    # q[(player, stat)][book] = {"line": x, "over": p, "under": p}
    q = defaultdict(lambda: defaultdict(dict))
    for b in g.get("prop_books", []):
        for m in b.get("markets", []):
            stat = STAT.get(m["key"], m["key"])
            for o in m.get("outcomes", []):
                player = o.get("description") or o["name"]
                d = q[(player, stat)][b["key"]]
                d["line"] = o.get("point")
                side = "under" if o["name"] in ("Under", "No") else "over"
                d[side] = o["price"]
    rows = []
    for (player, stat), books in q.items():
        line, src = ref_line({k: v.get("line") for k, v in books.items()})
        at = {k: v for k, v in books.items() if v.get("line") == line}
        probs = []
        for v in at.values():
            if "over" in v and "under" in v:
                io, iu = implied(v["over"]), implied(v["under"])
                probs.append(io / (io + iu))
            elif "over" in v and stat == "anytime_td":
                probs.append(implied(v["over"]) / TD_HOLD)
        bo = bob = bu = bub = None
        for k, v in at.items():
            if "over" in v and better(v["over"], bo):
                bo, bob = v["over"], k
            if "under" in v and better(v["under"], bu):
                bu, bub = v["under"], k
        fd = books.get(FD, {})
        fd_ok = fd.get("line") == line
        alt = sorted({f"{k} {v.get('line')}" for k, v in books.items() if v.get("line") != line})
        rows.append({"game": game, "player": player, "stat": stat, "line": "" if line is None else line,
                     "line_source": src,
                     "fd_over": fd.get("over", "") if fd_ok else "", "fd_under": fd.get("under", "") if fd_ok else "",
                     "best_over": bo or "", "best_over_book": bob or "", "best_under": bu or "", "best_under_book": bub or "",
                     "consensus_over_prob": round(statistics.median(probs), 4) if probs else "",
                     "n_books": len(at), "alt_lines": "; ".join(alt)})
    return rows


def candidates(games, props):
    rows = []
    for r in props:
        over = r["fd_over"] or r["best_over"]
        under = r["fd_under"] or r["best_under"]
        book = "fanduel" if r["fd_over"] or r["fd_under"] else (r["best_over_book"] or r["best_under_book"])
        rows.append({"game": r["game"], "market": "prop", "selection": r["player"], "stat": r["stat"], "proj": "",
                     "line": r["line"], "over_odds": over, "under_odds": under, "book": book,
                     "market_prob_over": r["consensus_over_prob"], "log": ""})
    pairs = defaultdict(dict)
    for r in games:
        pairs[(r["game"], r["market"])][r["selection"]] = r
    for (game, mkt), sides in pairs.items():
        if mkt == "total" and "Over" in sides and "Under" in sides:
            o, u = sides["Over"], sides["Under"]
            rows.append({"game": game, "market": "total", "selection": "Over", "stat": "", "proj": "",
                         "line": o["line"], "over_odds": o["fd_odds"] or o["best_odds"],
                         "under_odds": u["fd_odds"] or u["best_odds"], "book": "fanduel" if o["fd_odds"] else o["best_book"],
                         "market_prob_over": o["consensus_prob"], "log": ""})
        elif mkt in ("spread", "moneyline") and len(sides) == 2:
            away, home = game.split("@")
            if away in sides and home in sides:
                a, h = sides[away], sides[home]
                rows.append({"game": game, "market": mkt, "selection": away, "stat": "", "proj": "",
                             "line": a["line"], "over_odds": a["fd_odds"] or a["best_odds"],
                             "under_odds": h["fd_odds"] or h["best_odds"], "book": "fanduel" if a["fd_odds"] else a["best_book"],
                             "market_prob_over": a["consensus_prob"], "log": ""})
    return rows


def write(rows, path):
    if not rows:
        open(path, "w").close()
        return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date")
    ap.add_argument("--repo", default="avenjwilliams/nfl-odds-relay")
    ap.add_argument("--file")
    ap.add_argument("--out", default=".")
    a = ap.parse_args()
    if a.file:
        data, src = json.load(open(a.file)), a.file
    else:
        data, src = fetch(a.repo, a.date)
        if data is None:
            print(f"No relay file for {a.date} in {a.repo}. Fall back to web sources.")
            sys.exit(2)
    os.makedirs(a.out, exist_ok=True)
    gb, pb = [], []
    for g in data.get("games", []):
        gb += game_board(g)
        pb += props_board(g)
    write(gb, os.path.join(a.out, "game_board.csv"))
    write(pb, os.path.join(a.out, "props_board.csv"))
    write(candidates(gb, pb), os.path.join(a.out, "candidates_template.csv"))
    fetched = datetime.fromisoformat(data["fetched_at"])
    age_h = (datetime.now(timezone.utc) - fetched).total_seconds() / 3600
    books = sorted({b["key"] for g in data.get("games", []) for b in g.get("game_books", []) + g.get("prop_books", [])})
    fd_props = sum(1 for r in pb if r["fd_over"] or r["fd_under"])
    print(f"source: {src}")
    print(f"fetched_at: {data['fetched_at']} ({age_h:.1f} h ago) · credits left: {data.get('credits_remaining')}")
    print(f"books: {', '.join(books) or 'none'}")
    print(f"{len(data.get('games', []))} games · {len(gb)} game-line rows · {len(pb)} props "
          f"({fd_props} with a FanDuel price)")
    for n in data.get("notes", []):
        print("relay note:", n)


if __name__ == "__main__":
    main()
