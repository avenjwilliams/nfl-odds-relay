#!/usr/bin/env python3
"""Turn a projection plus a FanDuel line into a probability, an edge, and a verdict.

Batch mode (normal use): one CSV row per candidate bet.
    python3 price.py --csv candidates.csv --out priced.csv

Columns (header required; blank odds default to -110 each side):
    game, market, selection, stat, proj, line, over_odds, under_odds, log
  market : prop | spread | total | moneyline
  stat   : rec_yds | rush_yds | pass_yds | rush_rec_yds | receptions | completions | pass_att
           | rush_att | pass_td | anytime_td | ints        (props only)
  proj   : props -> projected stat mean (anytime_td -> expected TDs)
           spread/moneyline -> projected margin for `selection` (its points minus opponent's)
           total -> projected combined points
  line   : props/total -> the number;  spread -> selection's spread (e.g. -3.5);  moneyline -> blank
  over_odds / under_odds : American odds. For spread/moneyline, over_odds = selection's price,
           under_odds = the other side's price. For anytime_td put the Yes price in over_odds.
  log    : optional semicolon-separated recent game values for that stat (sharpens the variance)
  book, market_prob_over : optional; market_prob_over is the consensus no-vig probability of the
           over/selection side from load_lines.py and replaces the single-book vig removal.
  Rows with a blank proj are skipped.

Single bet:
    python3 price.py --market prop --stat rec_yds --proj 71 --line 64.5 --over -115 --under -105
"""
import argparse
import csv
import math
import sys

from scipy import stats

# Typical game-to-game coefficient of variation by stat (shrinkage targets).
DEFAULT_CV = {"rec_yds": 0.65, "rush_yds": 0.50, "rush_rec_yds": 0.45, "pass_yds": 0.25,
              "pass_att": 0.18, "completions": 0.22, "rush_att": 0.35}
COUNT_STATS = {"receptions", "pass_td", "anytime_td", "ints"}
MARGIN_SD = 13.5   # NFL final-margin SD around a market-quality projection
TOTAL_SD = 10.0    # NFL combined-points SD around a market-quality projection


def implied(american):
    a = float(american)
    return 100 / (a + 100) if a > 0 else -a / (-a + 100)


def payout(american):
    """Profit per 1 unit staked."""
    a = float(american)
    return a / 100 if a > 0 else 100 / -a


def fair_american(p):
    p = min(max(p, 1e-4), 1 - 1e-4)
    return round(-100 * p / (1 - p)) if p >= 0.5 else round(100 * (1 - p) / p)


def cv_for(stat, log):
    base = DEFAULT_CV[stat]
    if log and len(log) >= 5 and sum(log) > 0:
        mu = sum(log) / len(log)
        sd = (sum((x - mu) ** 2 for x in log) / (len(log) - 1)) ** 0.5
        emp = sd / mu if mu > 0 else base
        w = min(len(log), 12) / 24  # at most 50% weight on the player's own history
        return (1 - w) * base + w * min(max(emp, 0.1), 1.5)
    return base


def p_over_prop(stat, proj, line, log):
    if proj <= 0:
        return 0.0
    if stat == "anytime_td":
        return 1 - math.exp(-proj)  # P(at least one)
    if stat in COUNT_STATS:
        return 1 - stats.poisson.cdf(math.floor(line), proj)
    cv = cv_for(stat, log)
    shape = 1 / cv ** 2
    return 1 - stats.gamma.cdf(line, a=shape, scale=proj / shape)


def evaluate(market, stat, proj, line, over_odds, under_odds, log=None, market_prob_over=None):
    yes_only = market == "prop" and stat == "anytime_td" and under_odds in (None, "")
    over_odds = over_odds if over_odds not in (None, "") else -110
    under_odds = under_odds if under_odds not in (None, "") else -110
    proj = float(proj)
    if market == "prop":
        p = p_over_prop(stat, proj, float(line), log)
    elif market == "total":
        p = 1 - stats.norm.cdf(float(line), proj, TOTAL_SD)
    elif market == "spread":
        p = 1 - stats.norm.cdf(-float(line), proj, MARGIN_SD)  # cover = margin > -spread
    elif market == "moneyline":
        p = 1 - stats.norm.cdf(0, proj, MARGIN_SD)
    else:
        raise ValueError(market)

    if market_prob_over not in (None, ""):
        # consensus no-vig probability across books (from load_lines.py) beats one book's vig removal
        mkt_over = float(market_prob_over)
        mkt_under = 1 - mkt_over
    elif yes_only:
        mkt_over = implied(over_odds) / 1.06  # FanDuel TD markets ~6% hold when no "No" price
        mkt_under = 1 - mkt_over
    else:
        io, iu = implied(over_odds), implied(under_odds)
        mkt_over, mkt_under = io / (io + iu), iu / (io + iu)

    ev_over = p * payout(over_odds) - (1 - p)
    ev_under = (1 - p) * payout(under_odds) - p
    if yes_only or ev_over >= ev_under:
        side, prob, mkt, ev, price = "OVER/YES/SIDE", p, mkt_over, ev_over, over_odds
    else:
        side, prob, mkt, ev, price = "UNDER/NO/OTHER", 1 - p, mkt_under, ev_under, under_odds
    edge = prob - mkt
    # Game lines are far sharper than props, so they need roughly double the edge.
    k = 2.0 if market in ("spread", "total", "moneyline") else 1.0
    if ev >= 0.07 * k and edge >= 0.05 * k:
        tier = "A"
    elif ev >= 0.04 * k and edge >= 0.03 * k:
        tier = "B"
    elif ev >= 0.02 * k:
        tier = "lean"
    else:
        tier = "pass"
    return {"side": side, "model_prob": round(float(prob), 3), "market_no_vig": round(float(mkt), 3),
            "edge": round(float(edge), 3), "ev_per_unit": round(float(ev), 3), "price": price,
            "fair_odds": fair_american(prob), "tier": tier}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv")
    ap.add_argument("--out")
    ap.add_argument("--market")
    ap.add_argument("--stat", default="")
    ap.add_argument("--proj", type=float)
    ap.add_argument("--line", type=float, default=0)
    ap.add_argument("--over", default=-110)
    ap.add_argument("--under", default=-110)
    ap.add_argument("--log", default="")
    a = ap.parse_args()

    if a.csv:
        rows = list(csv.DictReader(open(a.csv)))
        out = []
        for r in rows:
            if not str(r.get("proj", "")).strip():
                continue
            log = [float(x) for x in r.get("log", "").split(";") if x.strip()]
            res = evaluate(r["market"].strip(), r.get("stat", "").strip(), r["proj"],
                           r.get("line") or 0, r.get("over_odds") or None, r.get("under_odds") or None, log,
                           r.get("market_prob_over") or None)
            out.append({**r, **res})
        out.sort(key=lambda x: -x["ev_per_unit"])
        w = csv.DictWriter(open(a.out, "w") if a.out else sys.stdout, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)
        if a.out:
            n = {t: sum(1 for x in out if x["tier"] == t) for t in ("A", "B", "lean", "pass")}
            print(f"priced {len(out)} candidates -> {a.out}  {n}")
    else:
        log = [float(x) for x in a.log.split(";") if x.strip()]
        print(evaluate(a.market, a.stat, a.proj, a.line, a.over, a.under, log))


if __name__ == "__main__":
    main()
