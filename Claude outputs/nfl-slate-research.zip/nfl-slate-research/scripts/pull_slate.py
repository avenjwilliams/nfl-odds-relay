#!/usr/bin/env python3
"""Pull free nflverse data for every NFL game on a date and write per-game research packets.

Usage:
    python3 pull_slate.py --date 2026-11-08 [--out slate_2026-11-08] [--recent 4]

Writes:
    <out>/slate.json            all games, machine-readable
    <out>/<game_id>.md          one readable packet per game
Requires: pip install nflreadpy pandas pyarrow --break-system-packages
"""
import argparse
import json
import os
import sys

import numpy as np
import pandas as pd
import nflreadpy as nfl

TEAM_ABBR_FIX = {"LA": "LAR"}  # nflverse uses LA for the Rams


def season_for(date):
    d = pd.Timestamp(date)
    return d.year if d.month >= 3 else d.year - 1


def pct(x):
    return None if x is None or pd.isna(x) else round(float(x) * 100, 1)


def r(x, n=3):
    return None if x is None or pd.isna(x) else round(float(x), n)


# ---------------------------------------------------------------- loading
def load(season):
    pbp = nfl.load_pbp([season]).to_pandas()
    pbp = pbp[(pbp["season_type"] == "REG") | (pbp["season_type"] == "POST")]
    plays = pbp[(pbp["pass"] == 1) | (pbp["rush"] == 1)].copy()
    plays = plays[plays["two_point_attempt"] != 1]
    try:
        ftn = nfl.load_ftn_charting([season]).to_pandas()
        ftn = ftn.rename(columns={"nflverse_game_id": "game_id", "nflverse_play_id": "play_id"})
        ftn["play_id"] = ftn["play_id"].astype(float)
        plays["play_id"] = plays["play_id"].astype(float)
        keep = ["game_id", "play_id", "is_play_action", "is_motion", "is_screen_pass", "is_rpo",
                "n_blitzers", "n_pass_rushers", "n_defense_box", "is_no_huddle"]
        plays = plays.merge(ftn[keep], on=["game_id", "play_id"], how="left")
        plays["has_ftn"] = plays["n_defense_box"].notna()
    except Exception as e:  # charting not out yet for the latest week, or not at all
        print(f"warning: FTN charting unavailable ({e})", file=sys.stderr)
        plays["has_ftn"] = False
    sched = nfl.load_schedules([season]).to_pandas()
    snaps = nfl.load_snap_counts([season]).to_pandas()
    inj = nfl.load_injuries([season]).to_pandas()
    players = nfl.load_players().to_pandas()[["gsis_id", "pfr_id", "display_name", "position"]]
    return plays, sched, snaps, inj, players


# ---------------------------------------------------------------- team metrics
def neutral(df):
    return df[(df["wp"].between(0.2, 0.8)) & (df["down"].isin([1, 2])) & (df["half_seconds_remaining"] > 120)]


def split(df, mask, label):
    sub = df[mask]
    if len(sub) < 15:
        return {"split": label, "plays": int(len(sub)), "epa": None, "success": None}
    return {"split": label, "plays": int(len(sub)), "epa": r(sub["epa"].mean()), "success": pct(sub["success"].mean())}


def play_type_splits(df):
    """EPA/success by play type. df is plays from one side's perspective (offense or defense)."""
    out = []
    p, ru = df["pass"] == 1, df["rush"] == 1
    out.append(split(df, p, "all dropbacks"))
    out.append(split(df, ru, "all rushes"))
    if df["has_ftn"].any():
        f = df["has_ftn"]
        out.append(split(df, f & p & (df["is_play_action"] == True), "play action"))
        out.append(split(df, f & p & (df["is_play_action"] == False), "no play action"))
        out.append(split(df, f & (df["is_motion"] == True), "with motion"))
        out.append(split(df, f & p & (df["is_screen_pass"] == True), "screens"))
        out.append(split(df, f & (df["is_rpo"] == True), "RPO"))
        out.append(split(df, f & p & (df["n_blitzers"] > 0), "dropbacks vs blitz"))
        out.append(split(df, f & p & (df["n_blitzers"] == 0), "dropbacks vs no blitz"))
        out.append(split(df, f & ru & (df["n_defense_box"] >= 7), "rushes vs 7+ box"))
        out.append(split(df, f & ru & (df["n_defense_box"] <= 6), "rushes vs light box (<=6)"))
    out.append(split(df, p & (df["air_yards"] >= 20), "deep throws (20+ air yds)"))
    out.append(split(df, df["yardline_100"] <= 20, "red zone"))
    return out


def team_block(plays, team, recent_weeks):
    off = plays[plays["posteam"] == team]
    de = plays[plays["defteam"] == team]
    weeks = sorted(off["week"].unique())
    last = weeks[-recent_weeks:] if weeks else []
    games = off["game_id"].nunique() or 1
    dgames = de["game_id"].nunique() or 1

    def summary(o, ng):
        n = neutral(o)
        drop = o[o["pass"] == 1]
        return {
            "plays_per_game": r(len(o) / max(ng, 1), 1),
            "neutral_pass_rate": pct(n["pass"].mean()) if len(n) else None,
            "proe": r(o["pass_oe"].mean(), 1),  # pass rate over expected, percentage points
            "epa_per_play": r(o["epa"].mean()),
            "success_rate": pct(o["success"].mean()),
            "pass_epa": r(drop["epa"].mean()),
            "rush_epa": r(o[o["rush"] == 1]["epa"].mean()),
            "explosive_rate": pct(((o["pass"] == 1) & (o["yards_gained"] >= 20) | (o["rush"] == 1) & (o["yards_gained"] >= 10)).mean()),
            "sack_rate": pct(drop["sack"].mean()) if len(drop) else None,
        }

    recent_off = off[off["week"].isin(last)]
    blk = {
        "team": team,
        "games": int(games),
        "offense_season": summary(off, games),
        "offense_recent": summary(recent_off, recent_off["game_id"].nunique()),
        "offense_splits": play_type_splits(off),
        "defense_allowed": summary(de, dgames),
        "defense_splits_allowed": play_type_splits(de),
    }
    if de["has_ftn"].any():
        dd = de[(de["has_ftn"]) & (de["pass"] == 1)]
        dr = de[(de["has_ftn"]) & (de["rush"] == 1)]
        blk["defense_tendencies"] = {
            "blitz_rate": pct((dd["n_blitzers"] > 0).mean()) if len(dd) else None,
            "avg_pass_rushers": r(dd["n_pass_rushers"].mean(), 2) if len(dd) else None,
            "loaded_box_rate_vs_run_7plus": pct((dr["n_defense_box"] >= 7).mean()) if len(dr) else None,
            "pressure_proxy_sack_rate": pct(dd["sack"].mean()) if len(dd) else None,
            "note": "Man/zone and shell rates are NOT in free 2026 data; get them from web research.",
        }
    # what the defense gives up by position-ish role, per game
    tgt = de[de["receiver_player_id"].notna()]
    blk["defense_target_profile"] = {
        "targets_per_game": r(len(tgt) / dgames, 1),
        "yards_per_target": r(tgt["yards_gained"].mean(), 2),
        "adot_allowed": r(tgt["air_yards"].mean(), 1),
        "rush_ypc_allowed": r(de[de["rush"] == 1]["yards_gained"].mean(), 2),
        "dropbacks_per_game_faced": r((de["pass"] == 1).sum() / dgames, 1),
    }
    return blk


# ---------------------------------------------------------------- players
def player_usage(plays, snaps, players, team, recent_weeks):
    off = plays[plays["posteam"] == team]
    weeks = sorted(off["week"].unique())
    last = weeks[-recent_weeks:] if weeks else []
    rows = {}

    def add(df, scope):
        team_att = (df["pass"] == 1).sum() - df["sack"].fillna(0).sum()
        team_air = df.loc[df["air_yards"].notna(), "air_yards"].clip(lower=0).sum()
        team_rush = (df["rush"] == 1).sum()
        ng = df["game_id"].nunique() or 1
        rec = df[df["receiver_player_id"].notna()].groupby(["receiver_player_id", "receiver_player_name"]).agg(
            targets=("play_id", "size"), rec=("complete_pass", "sum"),
            rec_yds=("yards_gained", lambda s: s[df.loc[s.index, "complete_pass"] == 1].sum()),
            air=("air_yards", "sum"), rz_tgt=("yardline_100", lambda s: (s <= 20).sum()),
            games=("game_id", "nunique"))
        for (pid, name), v in rec.iterrows():
            d = rows.setdefault(pid, {"id": pid, "name": name})
            d[f"{scope}_targets_pg"] = r(v.targets / ng, 1)
            d[f"{scope}_tgt_share"] = pct(v.targets / max(team_att, 1))
            d[f"{scope}_air_share"] = pct(max(v.air, 0) / max(team_air, 1))
            d[f"{scope}_adot"] = r(v.air / v.targets, 1)
            d[f"{scope}_rec_pg"] = r(v.rec / ng, 1)
            d[f"{scope}_rec_yds_pg"] = r(v.rec_yds / ng, 1)
            d[f"{scope}_ypt"] = r(v.rec_yds / v.targets, 2)
            d[f"{scope}_rz_targets"] = int(v.rz_tgt)
        ru = df[(df["rush"] == 1) & df["rusher_player_id"].notna()].groupby(["rusher_player_id", "rusher_player_name"]).agg(
            att=("play_id", "size"), yds=("yards_gained", "sum"),
            inside10=("yardline_100", lambda s: (s <= 10).sum()))
        for (pid, name), v in ru.iterrows():
            d = rows.setdefault(pid, {"id": pid, "name": name})
            d[f"{scope}_rush_att_pg"] = r(v.att / ng, 1)
            d[f"{scope}_rush_share"] = pct(v.att / max(team_rush, 1))
            d[f"{scope}_rush_yds_pg"] = r(v.yds / ng, 1)
            d[f"{scope}_ypc"] = r(v.yds / v.att, 2)
            d[f"{scope}_inside10_att"] = int(v.inside10)
        qb = df[(df["pass"] == 1) & df["passer_player_id"].notna()].groupby(["passer_player_id", "passer_player_name"]).agg(
            dropbacks=("play_id", "size"), sacks=("sack", "sum"), comp=("complete_pass", "sum"),
            ints=("interception", "sum"), games=("game_id", "nunique"))
        for (pid, name), v in qb.iterrows():
            if v.dropbacks < 15:
                continue
            g = df[df["passer_player_id"] == pid]
            att = v.dropbacks - v.sacks - g["qb_scramble"].fillna(0).sum()
            yds = g.loc[(g["complete_pass"] == 1), "yards_gained"].sum()
            d = rows.setdefault(pid, {"id": pid, "name": name})
            d[f"{scope}_pass_att_pg"] = r(att / v.games, 1)
            d[f"{scope}_comp_pg"] = r(v.comp / v.games, 1)
            d[f"{scope}_pass_yds_pg"] = r(yds / v.games, 1)
            d[f"{scope}_ypa"] = r(yds / max(att, 1), 2)
            d[f"{scope}_pass_td_pg"] = r(g["pass_touchdown"].sum() / v.games, 2)
            d[f"{scope}_int_pg"] = r(v.ints / v.games, 2)

    add(off, "season")
    add(off[off["week"].isin(last)], "recent")

    # game-by-game logs for variance estimates
    for pid, d in rows.items():
        log = []
        for gid, g in off.groupby("game_id"):
            rec_y = g[(g["receiver_player_id"] == pid) & (g["complete_pass"] == 1)]["yards_gained"].sum()
            recs = int(((g["receiver_player_id"] == pid) & (g["complete_pass"] == 1)).sum())
            rush_y = g[(g["rusher_player_id"] == pid) & (g["rush"] == 1)]["yards_gained"].sum()
            pass_y = g[(g["passer_player_id"] == pid) & (g["complete_pass"] == 1)]["yards_gained"].sum()
            log.append({"week": int(g["week"].iloc[0]), "rec": recs, "rec_yds": int(rec_y),
                        "rush_yds": int(rush_y), "pass_yds": int(pass_y)})
        d["game_log"] = sorted(log, key=lambda x: x["week"])

    # snap share (last game and recent average)
    idmap = players.dropna(subset=["pfr_id"]).set_index("pfr_id")["gsis_id"].to_dict()
    ts = snaps[snaps["team"].replace(TEAM_ABBR_FIX) == TEAM_ABBR_FIX.get(team, team)].copy()
    ts["gsis_id"] = ts["pfr_player_id"].map(idmap)
    if len(ts):
        lastw = ts["week"].max()
        rec_snaps = ts[ts["week"].isin(last)].groupby("gsis_id")["offense_pct"].mean()
        last_snaps = ts[ts["week"] == lastw].set_index("gsis_id")["offense_pct"]
        pos = players.set_index("gsis_id")["position"].to_dict()
        full = players.set_index("gsis_id")["display_name"].to_dict()
        for pid, d in rows.items():
            d["position"] = pos.get(pid)
            d["full_name"] = full.get(pid, d["name"])
            d["recent_snap_pct"] = pct(rec_snaps.get(pid)) if pid in rec_snaps else None
            d["last_game_snap_pct"] = pct(last_snaps.get(pid)) if pid in last_snaps else None

    out = [d for d in rows.values()
           if (d.get("season_targets_pg") or 0) >= 2 or (d.get("season_rush_att_pg") or 0) >= 4
           or d.get("season_pass_att_pg")]
    out.sort(key=lambda d: -((d.get("recent_tgt_share") or 0) + (d.get("recent_rush_share") or 0) + (100 if d.get("season_pass_att_pg") else 0)))
    return out


# ---------------------------------------------------------------- injuries
def injury_block(inj, team, week):
    t = inj[(inj["team"].replace(TEAM_ABBR_FIX) == TEAM_ABBR_FIX.get(team, team)) & (inj["week"] == week)]
    if not len(t):
        return {"week": int(week), "available": False, "players": []}
    t = t[(t["report_status"].notna()) | (t["practice_status"].fillna("").str.contains("Did Not|Limited", case=False))]
    return {"week": int(week), "available": True, "players": [
        {"name": row.full_name, "pos": row.position,
         "injury": next((x for x in (row.report_primary_injury, row.practice_primary_injury) if isinstance(x, str)), ""),
         "practice": row.practice_status if isinstance(row.practice_status, str) else "",
         "game_status": row.report_status if isinstance(row.report_status, str) else "not yet posted"}
        for row in t.itertuples()]}


# ---------------------------------------------------------------- formatting
def md_table(rows, cols, headers=None):
    headers = headers or cols
    lines = ["| " + " | ".join(headers) + " |", "|" + "---|" * len(cols)]
    for row in rows:
        lines.append("| " + " | ".join("" if row.get(c) is None else str(row.get(c)) for c in cols) + " |")
    return "\n".join(lines)


def game_md(g):
    a, h = g["away"], g["home"]
    out = [f"# {a['team']} @ {h['team']} — {g['gameday']} {g['gametime']} ET",
           f"Venue: {g['stadium']} · roof: {g['roof']} · surface: {g['surface']} · rest: {a['team']} {g['away_rest']}d / {h['team']} {g['home_rest']}d",
           f"nflverse consensus line (home perspective, positive = home favored): spread {g['spread_line']}, total {g['total_line']}",
           f"Implied team totals from consensus: {a['team']} {g['implied']['away']}, {h['team']} {g['implied']['home']}", ""]
    for side in (a, h):
        t = side
        out += [f"## {t['team']} offense", md_table([
            {"scope": "season", **t["offense_season"]}, {"scope": "last 4", **t["offense_recent"]}],
            ["scope", "plays_per_game", "neutral_pass_rate", "proe", "epa_per_play", "success_rate", "pass_epa", "rush_epa", "explosive_rate", "sack_rate"]), ""]
        opp = h if t is a else a
        out += [f"### {t['team']} offense vs {opp['team']} defense by play type",
                md_table([{"split": s["split"], "off_plays": s["plays"], "off_epa": s["epa"], "off_sr": s["success"],
                           "def_epa_allowed": d["epa"], "def_sr_allowed": d["success"]}
                          for s, d in zip(t["offense_splits"], opp["defense_splits_allowed"])],
                         ["split", "off_plays", "off_epa", "off_sr", "def_epa_allowed", "def_sr_allowed"]), ""]
        if opp.get("defense_tendencies"):
            out += [f"{opp['team']} defense tendencies: " + ", ".join(f"{k}={v}" for k, v in opp["defense_tendencies"].items()), ""]
        out += [f"{opp['team']} defense target profile: " + ", ".join(f"{k}={v}" for k, v in opp["defense_target_profile"].items()), ""]
        out += [f"### {t['team']} usage (season / last 4)", md_table(t["players"][:14],
                ["full_name", "position", "recent_snap_pct", "season_tgt_share", "recent_tgt_share", "recent_air_share", "recent_adot",
                 "recent_rec_yds_pg", "recent_rush_share", "recent_rush_yds_pg", "recent_inside10_att", "recent_pass_yds_pg"]), ""]
        inj = t["injuries"]
        out += [f"### {t['team']} injury report (week {inj['week']})"]
        if inj["available"] and inj["players"]:
            out += [md_table(inj["players"], ["name", "pos", "injury", "practice", "game_status"]), ""]
        else:
            out += ["No official report in nflverse yet — check web sources.", ""]
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", required=True, help="game date YYYY-MM-DD")
    ap.add_argument("--out", default=None)
    ap.add_argument("--recent", type=int, default=4)
    args = ap.parse_args()
    out = args.out or f"slate_{args.date}"
    os.makedirs(out, exist_ok=True)

    season = season_for(args.date)
    plays, sched, snaps, inj, players = load(season)
    games = sched[sched["gameday"] == args.date]
    if not len(games):
        print(f"No games on {args.date}.")
        return
    latest_inj_week = int(inj["week"].max()) if len(inj) else None
    slate = []
    for gm in games.itertuples():
        total, spread = gm.total_line, gm.spread_line
        implied = {"home": r((total + spread) / 2, 1) if pd.notna(total) and pd.notna(spread) else None,
                   "away": r((total - spread) / 2, 1) if pd.notna(total) and pd.notna(spread) else None}
        g = {"game_id": gm.game_id, "week": int(gm.week), "gameday": gm.gameday, "gametime": gm.gametime,
             "stadium": gm.stadium, "roof": gm.roof, "surface": gm.surface,
             "away_rest": int(gm.away_rest), "home_rest": int(gm.home_rest),
             "spread_line": r(spread, 1), "total_line": r(total, 1), "implied": implied}
        for side, team in (("away", gm.away_team), ("home", gm.home_team)):
            blk = team_block(plays, team, args.recent)
            blk["players"] = player_usage(plays, snaps, players, team, args.recent)
            blk["injuries"] = injury_block(inj, team, gm.week if latest_inj_week and gm.week <= latest_inj_week else latest_inj_week)
            g[side] = blk
        slate.append(g)
        with open(os.path.join(out, f"{gm.game_id}.md"), "w") as f:
            f.write(game_md(g))
    with open(os.path.join(out, "slate.json"), "w") as f:
        json.dump(slate, f, indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"{len(slate)} games written to {out}/ (data through week {int(plays['week'].max())})")
    for g in slate:
        print(f"  {g['game_id']}: {g['away']['team']} @ {g['home']['team']} {g['gametime']}")


if __name__ == "__main__":
    main()
